﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer_Market.Entities
{
   public  class EMSeller
    {
        private string sellerId;
        private string sellerName;
        private int sellerAge;
        private string sellerPhone;

        public string SellerID { get; set; }
        public string SellerName { get; set; }
        public int SellerAge { get; set; }
        public string SellerPhone { get; set; }




    }
}
