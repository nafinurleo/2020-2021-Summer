﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer_Market.Entities;
using System.Data.SqlClient;

namespace DataAccessLayer_Market.Operations
{
   public  class OMCategory
    {
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\user\Documents\MarketDATABASE.mdf;Integrated Security=True;Connect Timeout=30");
        public int Add(OMCategory add)
        {
            Con.Open();
            SqlCommand cmd = new SqlCommand("Insert into CategoryTbl(Catd, CatName,CatDesc) values('" + MCIDtxt.Catd + "','" + MCNAMEtxt.CatName + "','" + MCDESCtxt.CatDesc +"')", con); ;
            int flag= cmd.ExecuteNonQuery();
            return flag;
        }
    }
}
